const mongoose = require("mongoose");
const Chat = require("./models/chat.js");

main()
    .then(() =>{
        console.log("Connection Successful");
    })
    .catch(err => console.log(err));
async function main() {
    await mongoose.connect("mongodb://127.0.0.1:27017/Whatsapp");;
}

Chat.insertMany([
    {
    from : "Neha",
    to: "Rahul",
    msg: "Send me your exam sheets ",
    created_at: new Date()
    },
]);

Chat.insertMany([
    {
    from : "Neha",
    to: "Preeti",
    msg: "Send me your assignment files ",
    created_at: new Date()
    },
    {
    from : "rohit",
    to: "mohit",
    msg: "Send me your notes ",
    created_at: new Date()
    },
    {
    from : "Amit",
    to: "Sumit",
    msg: "Hey, how are you?",
    created_at: new Date()
    },
]).then((res) => {
    console.log(res);
});